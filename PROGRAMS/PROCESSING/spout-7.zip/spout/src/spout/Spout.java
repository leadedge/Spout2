package spout;

//========================================================================================================
//
//                  Spout.Java
//
//		Adds support to the functions of the JSpout JNI library.
//
//		19.12.15 - Finalised Library class
//				 - Changed all parent.println to System.out.println to prevent compiler warning
//				 - Changed "(boolean)(invertMode == 1)" to "(invertMode == 1)" to prevent compiler warning
//				 - Documented all functions
//				 - Cleanup - previous revisions in older Spout.pde file
//		12.02.16 - Changed "ReceiveTexture()" to update and draw a local graphics object
//				 - Removed java.awt import - not needed for Processing 3 frame sizing
//		15.02.16 - Removed "createSender" function console output
//		26.02.16 - Updated JNISpout library dll files - tested Processing 3.0.2 64bit and 32bit 
//				   Spout 2.005 SDK as at 26.02.16 - incremented library version number to 2.0.5.2
//		01.03.16 - Separated initialization flag to bSenderInitialized and bReceiverConnected
//				 - Added "updateSender" to JNISpout.java and the JNI dll
//				 - Introduced createSenderName using the sketch folder name as default
//		06.03.16 - Introduced object pointers for multiple senders / receivers
//		17.03.16 - Fixed release of receiver when the received sender closed
//		18.03.16 - Fixed initial detection of named sender for CreateReceiver
//		25.03.16 - Removed "Settings" from multiple examples to work with Processing 2.2.1
//		30.03.16 - Rebuild for Spout 2.005 release - version 2.0.5.3
//		28.04.16 - Added "receivePixels"
//		10.05.16 - Added SpoutControls example
//		12.05.16 - Library release - version 2.0.5.4
//		02.06.16 - Library release - version 2.0.5.5 for Spout 2.005 June 2016
//		07.07.16 - Updated for latest SDK functions
//				   co.zeal.spout project removed
//		09.10.16 - Introduced cleanup function for dispose
//				   https://github.com/processing/processing/issues/4381#issuecomment-252198109
//		15.01.17 - Change to Processing 3.2.3 core library.
//				   Added getShareMode - 0 Texture, 1 CPU, 2 Memory
//		26.01.17 - Rebuild for Spout 2.006 - version 2.0.6.0
//		27.01.17 - Some comment changes for CreateSender.
//				 - JNISpout - changes to OpenSpoutController to find a SpoutControls installation
//		08.02.17 - Change to Processing 3.2.4 core library.
//				 - SpoutControls example removed - duplicate of SpoutBox in the SpoutControls installation
//				 - Rebuild with current SDK files
//				 - Library release - version 2.0.6.0 for Spout 2.006 - February 2017
//		10.02.12 - Changed Build properties to java.target.version=1.8
//		16.06.17 - Added getSenderName, getSenderWidth, getSenderHeight
//				 - Update JNISpout
//		18.06.17 - Change to Processing 3.2.4 core library
//				 - Update Version to 2.0.7.0 for Spout 2.007
//		27.06.17 - Change to Processing 3.2.5 core library
//		17.11.18 - Updates for Spout 2.007
//				   New frame option for all SDK sending and receiving functions
//				   Add getSenderFps, getSenderFrame
//				   Change application CreateReceiver with name option to setupReceiver
//				   Change receiveTexture() to void, always draw graphics
//				   Change to Processing 3.4 core library
//		18.11.18 - Change return types for receive functions
//				   Simplified functions with object arguments passed by reference
//				   https://processing.org/tutorials/objects/
//				   Add receiveGraphics and receiveImage
//				   Allocate local graphics object in constructor
//		03.01.19 - Revise examples
//		26.01.19 - Change to Processing 3.5.2 core library
//				   Add logging functions
//				   Update JNISpout libraries
//		27.01.19 - Set InfoBox message dialog topmost so it does not get lost
//		25.04.19 - Add pgr.loadPixels() before getTexture in ReceiveTexture
//				   To avoid "pixels array is null" error the first time it is accessed
//				   Minor changes to code layout in createReceiver
//		20.05.19 - Change setupReceiver to setReceiverName
//				   Change receiveTexture from void to boolean. Updated receiver examples.
//				   Add if(pgs.loaded to drawTexture
//		04.06.19   Rebuild with 2.007 SDK and JNISpout library
//		06.06.19   Rebuild for 256 max senders for 2.007
//		10.06.19   Changed Eclipse compiler compliance to Java 1.8
//		13.10.19   Rebuild for revised Spout SDK
//		27.11.19   Rebuild for revised Spout SDK
//		22.01.20   Update to Processing 3.5.4 core
//				   Removed setupSender function - createSender still used 
//				   Rebuild for revised 2.007 Spout SDK and JNISpout library
//
// ========================================================================================================


import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PGraphics;
import processing.core.PImage;
import processing.opengl.*;

import javax.swing.JFrame;
import javax.swing.JOptionPane; // for infoBox

/**
 * Main Class to use with Processing
 * 
 * @author Lynn Jarvis, Martin Froehlich
 *
 */
public class Spout {
	
	// A pointer to the spout object created
	long spoutPtr;
	PApplet parent;
	PGraphicsOpenGL pgl;
	PGraphics pgs; // local graphics object for receiving textures
	String senderName; // the sender name
	String userSenderName; // user specified sender name for CreateReceiver
	int[] dim = new int[2]; // Sender dimensions
	boolean bSenderInitialized; // sender initialization flag
	boolean bReceiverConnected; // receiver initialization flag
	boolean bPixelsLoaded;
	int receiverType; // 0 - parent, 1 - graphics, 2 - image
	int invertMode; // User setting for texture invert
	
	/**
	 * Create a Spout Object.
	 * 
	 * A spout object is created within the JNI dll
	 * and a pointer to it saved in this class for
	 * use with all functions.
	 * 
	 * @param parent : parent sketch
	 */
	public Spout (PApplet parent) {
	
		// A pointer to the new spout object for this instance
		spoutPtr = JNISpout.init();

		if(spoutPtr == 0) 
			PGraphics.showWarning("Spout initialization failed");

		this.parent = parent;
		
		pgl = (PGraphicsOpenGL) parent.g;
		dim[0] = 0; // Sender width
		dim[1] = 0; // Sender height
		bSenderInitialized = false;
		bReceiverConnected = false;
		bPixelsLoaded = false;
		senderName = "";
		userSenderName = "";
		receiverType = 0; // receive to parent graphics
		invertMode = -1; // User has not set any mode - use function defaults
		// Initialize a local graphics object in advance for receiveTexture
		pgs = parent.createGraphics(parent.width, parent.height, PConstants.P2D);
		
		parent.registerMethod("dispose", this);
		
	}  
	
	/**
	 * Can be called from the sketch to release the library resources.
	 * Such as from an over-ride of "exit" in the sketch for Processing 3.0.2
	 */
	public void release() {
		 // infoBox("Spout release");
		 dispose();
	}
		
	/**
	  * This method should be called automatically when the sketch is disposed.
	  * Differences observed between Processing versions :
	  * 3.0.1 calls it for [X] window close or esc but not for the "Stop" button,
	  * 3.0.2 does not call it at all.
	  * 3.2.3 calls it for esc or [X] but not for the stop button.
	  * 3.5.2 calls it for esc or [X] but not for the stop button.
	  * 3.5.4 calls it for esc or [X] but not for the stop button.
	  * Senders are apparently released because they can't be detected subsequently.  
	  */
	 public void dispose() {
		// infoBox("Spout dispose");
		spoutCleanup();
	}

	/**
	 * The class finalizer - adapted from Syphon.
	 * Never seems to be called.
	 */
	protected void finalize() throws Throwable {
		// infoBox("Spout finalize");
		try {
			spoutCleanup();
	    } finally {
	    	super.finalize();
	    }
	} 

	  
	// =========================================== //
	//                   SENDER                    //
	// =========================================== //
	
	/**
	 * Initialize a sender name.
	 * If the name is not specified, the sketch folder name is used.
	 * 
	 * @param name : sender name
	 */
	public void createSenderName(String name) {
		 
		if(name.isEmpty() || name.equals("") ) {
			String path = parent.sketchPath();
			int index = path.lastIndexOf("\\");
			senderName = path.substring(index + 1);
		}
		else {
			senderName = name;
		}
	}
		
	/**
	 * Initialize a sender with the sketch window dimensions.
	 * If the sender name is not specified, the sketch folder name is used.
	 * 
	 * @param name : sender name (up to 256 characters)
	 * @return true if the sender was created
	 */	
	public boolean createSender(String name) {
		createSenderName(name);
		return createSender(name, parent.width, parent.height);
	}	
		
	/**
	 * Initialize a sender.
	 * 
	 * The name provided is registered in the list of senders
	 * Initialization is made using or whatever the user has selected
	 * with SpoutDXmode : Texture, CPU or Memory. Texture share only 
	 * succeeds if the graphic hardware is compatible, otherwise it
	 * defaults to CPU texture share mode.
	 *  
	 * @param name : sender name (up to 256 characters)
	 * @param Width : sender width
	 * @param Height : sender height
	 * @return true if the sender was created
	 */
	public boolean createSender(String name, int Width, int Height) {
		createSenderName(name);
		if(JNISpout.createSender(senderName, Width, Height, spoutPtr)) {
			bSenderInitialized = true;
			dim[0] = Width;
			dim[1] = Height;
			System.out.println("Created sender '" + senderName + "' (" + dim[0] + "x" + dim[1] + ")");
			spoutReport(bSenderInitialized); // console report
		}
		return bSenderInitialized;
	}
	
	/**
	 * Update the size of the current sender
	 * 
	 * @param Width : new width
	 * @param Height : new height
	 */
	public void updateSender(int Width, int Height) {
		
		if(bSenderInitialized) { // There is a sender name
			JNISpout.updateSender(senderName, Width, Height, spoutPtr);
			dim[0] = Width;
			dim[1] = Height;
		}
	}
	
	/**
	 * Close the sender. 
	 * 
	 * This releases the sender name from the list of senders
	 * and releases all resources for the sender.
	 */
	public void closeSender() {
		if(bSenderInitialized) {
			if(JNISpout.releaseSender(spoutPtr))
				System.out.println("Sender was closed");
			else
				System.out.println("No sender to close");
			bSenderInitialized = false;
		}
	} 

	/**
	 *	Write the sketch drawing surface texture to 
	 *	an opengl/directx shared texture
	 */
	public void sendTexture() {

		if(!bSenderInitialized)	{
			// Create a sender the dimensions of the sketch window
			createSender(senderName, parent.width, parent.height);
			return;
		}
		else if(dim[0] != parent.width || dim[1] != parent.height) {
			// Update the dimensions of the sender
			updateSender(parent.width, parent.height);
			return;
		}

		// Set the invert flag to the user setting if it has been selected
		// Processing Y axis is inverted with respect to OpenGL
		// so we need to invert the texture for this function
		boolean bInvert = true; 
		if(invertMode >= 0) bInvert = (invertMode == 1);
		
		pgl.beginPGL();
		// Load the current contents of the renderer's
		// drawing surface into its texture.
		pgl.loadTexture();
		// getTexture returns the texture associated with the
		// renderer's drawing surface, making sure is updated 
		// to reflect the current contents off the screen 
		// (or offscreen drawing surface).      
		Texture tex = pgl.getTexture();
		JNISpout.sendTexture(tex.glWidth, tex.glHeight, tex.glName, tex.glTarget, bInvert, spoutPtr);
		pgl.endPGL();

	}
	
	/**
	 * Write the texture of a graphics object.
	 * 
	 * @param pgr : the graphics object to be used.
	 */
	public void sendTexture(PGraphics pgr)
	{
		if(!bSenderInitialized) {
			// Create a sender the dimensions of the graphics object
			dim[0] = pgr.width;
			dim[1] = pgr.height;
			createSender(senderName, dim[0], dim[1]);
			return;
		}
		else if(dim[0] != pgr.width || dim[1] != pgr.height) {
			// Update the dimensions of the sender
			updateSender(pgr.width, pgr.height);
			return;
		}
		
		boolean bInvert = true;
		if(invertMode >= 0) bInvert = (invertMode == 1);
		Texture tex = pgl.getTexture(pgr);
		JNISpout.sendTexture(tex.glWidth, tex.glHeight, tex.glName, tex.glTarget, bInvert, spoutPtr);

	}

	/**
	 *  Write the texture of an image object.
	 *  
	 * @param img : the image to be used.
	 */
	public void sendTexture(PImage img)
	{
		if(!bSenderInitialized)	{
			// Create a sender the dimensions of the image object
			createSender(senderName, img.width, img.height);
			return;
		}
		else if(dim[0] != img.width || dim[1] != img.height) {
			// Update the dimensions of the sender
			updateSender(img.width, img.height);
			return;
		}
		
		boolean bInvert = false; // default for this function
		if(invertMode >= 0) bInvert = (invertMode == 1);
		Texture tex = pgl.getTexture(img);
		JNISpout.sendTexture(tex.glWidth, tex.glHeight, tex.glName, tex.glTarget, bInvert, spoutPtr);

	}

	
	// =========================================== //
	//                   RECEIVER                  //
	// =========================================== //
	
	/**
	 * 	Set a sender name to receive from
	 * 
	 * @param name : sender name to be used
	 */
	 public void setReceiverName(String name) {
		 userSenderName = name;
	 }

	/**
	 * 	Create a Receiver. 
	 * 
	 * Create receiver using the system sender name
	 * @return true if connection with a sender succeeded
	 */
	public boolean createReceiver() {
		// Pass the user specified sender name
		return createReceiver(userSenderName);
	}
	
	/**
	 *  Create a Receiver. 
	 * 
	 * If the named sender is not running or if the name is not specified,
	 * the receiver will attempt to connect with the active sender.
	 * If the sender is found, the name is returned and set.
	 *  
	 * @param name : sender name to be used
	 * @return true if connection with a sender succeeded
	 */
	public boolean createReceiver(String name) {
		
		// Image size values passed in are modified and passed back
		// as the size of the sender that the receiver connects to.
		dim[0] = parent.width;
		dim[1] = parent.height;
		String newname;
		
		// Use the user specified sender name if any.
		// If it is empty, the receiver will connect to the active sender 
		if(name.isEmpty() || name.equals("") ) {
			name = userSenderName;
		}
		
		if(JNISpout.createReceiver(name, dim, spoutPtr)) {
			// Initialization succeeded and there was a sender running
			newname = getSenderName();
			// dim will be returned with the size of the sender it connected to
			if(newname != null && !newname.isEmpty() && newname.length() > 0) {
				// Set the global sender name
				senderName = newname;
				dim[0] = JNISpout.getSenderWidth(spoutPtr);
				dim[1] = JNISpout.getSenderHeight(spoutPtr);
				bReceiverConnected = true;
				spoutReport(true);
				// Once connected, the user can select new senders
				// and ReceiveTexture adapts to the change without
				// needing to call createReceiver again
				return true;
				
			}
		}

		bReceiverConnected = false;
		return false;

	} // end createReceiver
	
	/**
	 * @return receiver status
	 */
	public boolean isReceiverConnected() {
		return bReceiverConnected;
	} 

	/**
	 * Close a receiver.
	 * All resources of the receiver are released.
	 */
	public void closeReceiver() {
		if(JNISpout.releaseReceiver(spoutPtr))
			System.out.println("Receiver closed");
		else
			System.out.println("No receiver to close");
		bReceiverConnected = false;
	} 
	
	/**
	 * Receive into local graphics
	 * @return result
	 */
	public boolean receiveTexture()
	{
		if(isConnected()) {
			pgs = receiveGraphics(pgs);
			return true;
		}
		return false;
	}
	
	/**
	 * Draw the local graphics
	 */
	public void drawTexture()
	{
		if(pgs.loaded && pgs.displayable())
			parent.image(pgs, 0, 0, parent.width, parent.height);
	}
	
	/**
	 * Receive into graphics
	 * 
	 * @param pgr : the graphics to be used
	 * @return changed graphics
	 */
	public PGraphics receiveTexture(PGraphics pgr)
	{
		return receiveGraphics(pgr);
	}
	
	/**
	 * Receive into an image
	 * 
	 * @param img : the image to be used
	 * @return changed image
	 */
	public PImage receiveTexture(PImage img) {
		return receiveImage(img);
	}
	
	/**
	 * Receive a local graphics texture
	 */
	public void receiveGraphics()
	{
		pgs = receiveGraphics(pgs);
	}
	
	/**
	 * Receive a graphics texture
	 * 
	 * @param pgr : the graphics to be used
	 * @return changed graphics
	 */
	public PGraphics receiveGraphics(PGraphics pgr)
	{	
		
		boolean bInvert = true; // default for this function
		if(invertMode >= 0) bInvert = (invertMode == 1);
		
		// If not connected keep looking
		if(!isConnected())
			return pgr;
		
		
		if(pgr == null ) {
			// Create a graphics object if the user has not done so
			pgr = parent.createGraphics(parent.width, parent.height, PConstants.P2D);
		}
		else if(dim[0] != pgr.width || dim[1] != pgr.height && dim[0] > 0 && dim[1] > 0) {
			// Adjust the graphics to the current sender size
			pgr = parent.createGraphics(dim[0], dim[1], PConstants.P2D);
		}		
		else if(bReceiverConnected) {
			// Receive a texture if connected
			// Sender dimensions (dim) are sent as well as returned
			// If the sender changes size, the graphics is adjusted next time round
			if(!bPixelsLoaded) {
				pgr.loadPixels();
				bPixelsLoaded = true;
			}
			Texture tex = pgl.getTexture(pgr);
			if(!JNISpout.receiveTexture(dim, tex.glName, tex.glTarget, bInvert, spoutPtr)) {
				JNISpout.releaseReceiver(spoutPtr);
				pgr.updatePixels(); // Clear the graphics of the last frame
				bReceiverConnected = false;
			}
		}
		
		// created pgr must be returned for the new size
		return pgr;
	}
	
	/**
	 * Receive an image texture
	 * 
	 * @param img : the image to be used
	 * @return changed image
	 */
	public PImage receiveImage(PImage img) {
		
		// If not connected keep looking
		if(!isConnected())
			return img;
		
		if(img == null ) {
			// Create an image object if the user has not done so
			img = parent.createImage(parent.width, parent.height, PConstants.ARGB);
		}
		else if(dim[0] != img.width || dim[1] != img.height && dim[0] > 0 && dim[1] > 0) {
			// Adjust the image to the current sender size
			img = parent.createImage(dim[0], dim[1], PConstants.ARGB);
		}		
		else if(bReceiverConnected) {		
			// Receive into local graphics first
			pgs = receiveGraphics(pgs);
			// Use the PGraphics texture as the cache object for the image
			// Adapted from Syphon client code
			// https://github.com/Syphon/Processing/blob/master/src/codeanticode/syphon/SyphonClient.java
			Texture tex = pgl.getTexture(pgs);
		    pgl.setCache(img, tex);			
		}
		// created img must be returned for the new size
		return img;
	}	
	
		
	/**
	 * Is the receiver connected to a sender?
	 *
	 * @return new frame status
	 */
	public boolean isConnected() {
		if(!bReceiverConnected) {
			// If no sender, keep looking
			if(!createReceiver())
				return false;
		}
		return true;
	}	
	
	/**
	 * Get the current sender name
	 * Checks for sender existence 
	 * 
	 * @return sender name
	 */
	public String getSenderName()
	{
		return JNISpout.getSenderName(spoutPtr);
	}
	
	/**
	 * Get the current sender width
	 * 
	 * @return sender width
	 */
	public int getSenderWidth()
	{
		return dim[0];
	}
	
	/**
	 * Get the current sender height
	 * 
	 * @return sender height
	 */
	public int getSenderHeight()
	{
		return dim[1];
	}

	/**
	 * Get the current sender frame rate
	 * 
	 * @return fps
	 */
	public int getSenderFps()
	{
		// Avoid integer truncation as far as possible
		return Math.round(JNISpout.getSenderFps(spoutPtr)+0.5f);
	}

	/**
	 * Get the current sender frame number
	 * 
	 * @return frame number
	 */
	public int getSenderFrame()
	{
		 return JNISpout.getSenderFrame(spoutPtr);
	}
	
	/**
	 * Is the received frame new
	 * 
	 * isFrameNew can be used after receiving a texture 
	 * to return whether the received frame is new.
	 * It is only necessary if there is a special application for it.
	 *  
	 * @return status
	 */
	public boolean isFrameNew()
	{
		 return JNISpout.isFrameNew(spoutPtr);
	}

	/**
	 * Disable frame counting for this application
	 * 
	 */
	public void disableFrameCount()
	{
		 JNISpout.disableFrameCount(spoutPtr);
	}
	
	/**
	 * Pop up SpoutPanel to select a sender.
	 * 
	 * If the user selected a different one, attach to it.
	 * Requires Spout installation 2.004 or higher.
	 */
	public void selectSender()
	{
		JNISpout.senderDialog(spoutPtr);
	}
	
	/*
	 * Enable logging to default console output
	 */
	public void enableSpoutLog()
	{
		JNISpout.enableSpoutLog(spoutPtr);
	}
	
	/*
	 * Log to a file
	 */
	public void enableSpoutLogFile(String filename)
	{
		JNISpout.spoutLogToFile(filename, false, spoutPtr);
	}
	
	/*
	 * Append logs to a file
	 */
	public void enableSpoutLogFile(String filename, boolean append)
	{
		JNISpout.spoutLogToFile(filename, append, spoutPtr);
	}	
	
	/*
	 * Set the Spout log level
	 * @param level
	 * 0 - Disable : 1 - Verbose : 2 - Notice (default)
	 * 3 - Warning : 4 - Error   : 5 - Fatal
	 */
	public void setLogLevel(int level)
	{
		JNISpout.spoutLogLevel(level, spoutPtr);
	}
	
	/**
	 * Log
	 * @param text - log text
	 *  
	 */
	public void spoutLog(String text)
	{
		JNISpout.spoutLog(text, spoutPtr);
	}
		
	/**
	 * Verbose log
	 * @param text - log text
	 *  
	 */
	public void spoutLogVerbose(String text)
	{
		JNISpout.spoutLogVerbose(text, spoutPtr);
	}
	
	/**
	 * Notice log
	 * @param text - log text
	 *  
	 */
	public void spoutLogNotice(String text)
	{
		JNISpout.spoutLogNotice(text, spoutPtr);
	}
	
	/**
	 * Warning log
	 * @param text - log text
	 *  
	 */
	public void spoutLogWarning(String text)
	{
		JNISpout.spoutLogWarning(text, spoutPtr);
	}
	
	/**
	 * Error log
	 * @param text - log text
	 *  
	 */
	public void spoutLogError(String text)
	{
		JNISpout.spoutLogError(text, spoutPtr);
	}
	
	/**
	 * Fatal log
	 * @param text - log text
	 *  
	 */
	public void spoutLogFatal(String text)
	{
		JNISpout.spoutLogFatal(text, spoutPtr);
	}
	
	/**
	 * Resize the receiver drawing surface and sketch window to that of the sender
	 * 
	 * Requires Processing 3+
	 */
	public void resizeFrame()
	{
		if(!bReceiverConnected) return;
		if(parent.width != dim[0] || parent.height != dim[1]  && dim[0] > 0 && dim[1] > 0) {
			// Only for Processing 3
			parent.getSurface().setSize(dim[0], dim[1]);
		}
	}

	/**
	 * Release everything
	 */
	public void spoutCleanup()
	{
		if(bSenderInitialized) JNISpout.releaseSender(spoutPtr);
		if(bReceiverConnected) JNISpout.releaseReceiver(spoutPtr);
		if(spoutPtr > 0) JNISpout.deInit(spoutPtr);
		bSenderInitialized = false;
		bReceiverConnected = false;
		spoutPtr = 0;
    }
	
	

	// =========================================== //
	//               SPOUTCONTROLS                 //
	// =========================================== //
	
	/**
	 * Create a control with defaults.
	 * 
	 * @param name - control name
	 * @param type - text (string), bool, event or float
	 * @return true for success
	 */
	public boolean createSpoutControl(String name, String type) {
		return(JNISpout.createControl(name, type, 0, 1, 1, "", spoutPtr));
	}

	/**
	 * Create a control with default value.
	 * 
	 * @param name : control name
	 * @param type : text, float, bool or event
	 * @param value : default value
	 * @return true for success
	 */
	public boolean createSpoutControl(String name, String type, float value) {
		return(JNISpout.createControl(name, type, 0, 1, value, "", spoutPtr));
	}

	/**
	 * Create a text control with default string.
	 * 
	 * @param name : control name
	 * @param type : text
	 * @param text : default text
	 * @return true for success
	 */	
	public boolean createSpoutControl(String name, String type, String text) {
		return(JNISpout.createControl(name, type, 0, 1, 1, text, spoutPtr));
	}

	/**
	 * Create a float control with defaults.
	 * Minimum, Maximum, Default
	 * 
	 * @param name : control name
	 * @param type : float
	 * @param minimum : minimum value
	 * @param maximum : maximum value
	 * @param value : default value
	 * @return true for success
	 */	
	public boolean createSpoutControl(String name, String type, float minimum, float maximum, float value) {
		return(JNISpout.createControl(name, type, minimum, maximum, value, "", spoutPtr));
	}

	/**
	 * Open SpoutControls
	 * 
	 * A sender creates the controls and then calls OpenControls with a control name
	 * so that the controller can set up a memory map and share data with the sender
	 * as it changes the controls.
	 * @param name : control map name (the sender name)
	 * @return true for success
	 */
	public boolean openSpoutControls(String name) {
		return(JNISpout.openControls(name, spoutPtr));
	}
	
	/**
	 * Check the controller for changed controls.
	 * 
	 * The value or text string are changed depending on the control type.
	 * 
	 * @param controlName : name of control
	 * @param controlType : type : text, float, bool, event 
	 * @param controlValue : value
	 * @param controlText : text
	 * @return The number of controls. Zero if no change.
	 */
	public int checkSpoutControls(String[] controlName, int[] controlType, float[] controlValue, String[] controlText ) {
		return JNISpout.checkControls(controlName, controlType, controlValue, controlText, spoutPtr);
	}
	
	/**
	 * Open the SpoutController executable to allow controls to be changed.
	 * 
	 * Requires SpoutControls installation
	 * or SpoutController.exe in the sketch path
	 * 
	 * @return true if the controller was found and opened
	 */
	public boolean openController() {
		return(JNISpout.openController(parent.sketchPath(), spoutPtr));
	}
	
	/**
	 * Close the link with the controller.
	 * 
	 * @return true for success
	 */
	public boolean closeSpoutControls() {
		return(JNISpout.closeControls(spoutPtr));
	}

	// =========================================== //
	//               SHARED MEMORY                 //
	// =========================================== //
	
	/**
	 * Create a sender memory map.
	 * 
	 * @param name : sender name
	 * @param Width : map width
	 * @param Height : map height
	 * @return True for success
	 */
	public boolean createSenderMemory(String name, int Width, int Height) 
	{
		return (JNISpout.createSenderMemory(name, Width, Height, spoutPtr));
	}
	
	/**
	 * Change the size of a sender memory map.
	 * 
	 * @param name Sender name
	 * @param Width : new map width
	 * @param Height : new map height
	 * @return True for success
	 */
	public boolean updateSenderMemorySize(String name, int Width, int Height) 
	{
		return (JNISpout.updateSenderMemorySize(name, Width, Height, spoutPtr));
	}
	
	/**
	 * Write a string to the memory map.
	 * 
	 * The map size must be sufficient for the string.
	 * @param sValue : string to be written
	 * @return True for success
	 */
	public boolean writeSenderString(String sValue) 
	{
		return (JNISpout.writeSenderString(sValue, spoutPtr));
	}
	
	/**
	 * Close a sender memory map.
	 */
	public void closeSenderMemory() 
	{
		JNISpout.closeSenderMemory(spoutPtr);
	}
	/**
	 * Lock a memory map for write or read access.
	 * 
	 * @return Size of the memory map
	 */
	public long lockSenderMemory() 
	{
		return JNISpout.lockSenderMemory(spoutPtr);
	}

	/** 
	 * Unlock a memory map after locking.
	 * 
	 */
	public void unlockSenderMemory() 
	{
		JNISpout.unlockSenderMemory(spoutPtr);
	}
		
	// =========================================== //
	//                   UTILITY                   //
	// =========================================== //

	/**
	 * User option to set texture inversion for send and receive
	 * 
	 * @param bInvert : true or false as required
	 */
	public void setInvert(boolean bInvert)
	{
		// invertMode is -1 unless the user specifically selects it
		if(bInvert)
			invertMode = 1;
		else
			invertMode = 0;
	}

	/**
	 * Print current settings to the console.
	 * 
	 * @param bInit : the initialization mode
	 */
	public void spoutReport(boolean bInit)
	{
		int ShareMode = 0; // Texture share default
		if(bInit) {
			ShareMode = JNISpout.getShareMode(spoutPtr);
			if(ShareMode == 2)
				System.out.println("Spout initialized memory sharing");
			else if(ShareMode == 1)
				System.out.println("Spout initialized CPU texture sharing");
			else
				System.out.println("Spout initialized texture sharing");
		}
		else {
			PGraphics.showWarning("Spout intialization failed");
		}
	}
	
	/**
	 * Pop up a MessageBox dialog
	 * 
	 * @param infoMessage : the message to show
	 */
	public void infoBox(String infoMessage)
    {
        // JOptionPane.showMessageDialog(null, infoMessage, "Spout", JOptionPane.INFORMATION_MESSAGE);
		// Set message dialog topmost so it does not get lost
		JFrame jf=new JFrame();
        jf.setAlwaysOnTop(true);
        JOptionPane.showMessageDialog(jf, infoMessage, "Spout", JOptionPane.INFORMATION_MESSAGE);
    }	

} // end class Spout

